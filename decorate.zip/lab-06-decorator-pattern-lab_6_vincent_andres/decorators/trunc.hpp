#ifndef __TRUNCATE_HPP__
#define __TRUNCATE_HPP__
#include "decorator.hpp"
class Truncate : public Decorator{
    public:
	Truncate(Base* val) : Decorator(val){};
	virtual double evaluate(){};
	virtual std::string stringify(){return (std::to_string(op->evaluate()));}
};


#endif //__TRUNCATE_HPP__
