#ifndef __ABS_HPP__
#define __ABS_HPP__

#include <cmath>
#include "decorator.hpp"

class Abs : public Decorator{

    public:
	Abs(Base* val) : Decorator(val){};
	virtual double evaluate()
	{
	     
            return std::abs(op->evaluate());

	};
	virtual std::string stringify(){return (std::to_string(op->evaluate()));};
        
};


#endif //__ABS_HPP__
