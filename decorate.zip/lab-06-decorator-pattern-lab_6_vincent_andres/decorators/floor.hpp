#ifndef __FLOOR_HPP__
#define __FLOOR_HPP__

#include "decorator.hpp"

class Floor : public Decorator{

    public:
	Floor(Base* val) : Decorator(val){};
	virtual double evaluate(){return (double)(((int)(op->evaluate())));
};
	virtual std::string stringify(){return (std::to_string(op->evaluate()));};
        
};


#endif //__Floor_HPP__
