#include "gtest/gtest.h"
#include "tests_mocks/ceil_test.hpp"
#include "tests_mocks/abs_test.hpp"
#include "tests_mocks/floor_test.hpp"
//#include "tests_mocks/combo_test.hpp"

int main(int argc, char **argv) {
  ::testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}
