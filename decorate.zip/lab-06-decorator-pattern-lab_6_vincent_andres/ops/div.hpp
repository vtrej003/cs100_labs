#ifndef __DIV_HPP__
#define __DIV_HPP__

#include "base.hpp"

class Div : public Base {
    private:
        Base* operand1;
        Base* operand2;
    public:
        Div(Base* value1, Base* value2) : Base() {operand1 = value1; operand2 = value2; }
        virtual double evaluate() { return operand1->evaluate()/operand2->evaluate(); }
        virtual std::string stringify() {return operand1->stringify()+"/"+operand2->stringify();}
};
#endif //__DIV_HPP__

