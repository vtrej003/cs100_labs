#ifndef __POW_HPP__
#define __POW_HPP__

#include "/home/csmajs/aestr074/lab-05-strategy-pattern-vincent_andres_lab_5/base.hpp"

class Pow : public Base {
    public:
        Pow( Base* a, Base* b)
        {
            this->base = a;
            this->exp = b;
        };
        virtual double evaluate()
        {
            double baseValue = base->evaluate();
            double expValue = exp->evaluate();
            double returnValue =  baseValue;

            if(expValue == 0)
            {
                return 1;
            }
            else
            {
                for(int i = expValue; i > 1; i--)
                {
                    returnValue *= baseValue;
                }
                return returnValue;
            }
        }
        virtual std::string stringify()
        {
            return base->stringify() + "**" + exp->stringify();
        }
    protected:
    Base* base = NULL;
    Base* exp = NULL;
};

#endif //__POW_HPP__

