#include "gtest/gtest.h"
#include "../decorators/decorator.hpp"
#include "../decorators/ceil.hpp"
#include "../ops/op.hpp"

TEST(CeilTest, RoundingUp) 
{
    Base* temp = new Op(3.5);
    Base* test = new Ceil(temp);
    
    std::cout << test->stringify() << std::endl;
   
    EXPECT_EQ(test->evaluate(), 4);
}
