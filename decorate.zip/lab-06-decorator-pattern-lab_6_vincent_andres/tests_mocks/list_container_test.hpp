#pragma once
#ifndef __LIST_CONTAINER_TEST__
#define __LIST_CONTAINER_TEST__

#include "gtest/gtest.h"
#include "container.hpp"
#include "list_container.hpp"
#include "sort.hpp"
#include "selection_sort.hpp"
#include "ops/op.hpp"
#include "ops/mult.hpp"
#include "ops/add.hpp"
#include "ops/sub.hpp"

TEST(ListContainerTestSet, listAddSizeAtTest) 
{
    //Setup the elements under test
    Op* seven = new Op(7);
    ListContainer *test_container = new ListContainer();
  
    //Exercisee some func of the test element
    test_container->add_element(seven);

    //Assert that the container has at least a single element
    //otherwise we are likely to cause a segfault when accessing
    ASSERT_EQ(test_container->size(), 1);
    EXPECT_EQ(test_container->at(0)->evaluate(), 7);
}

TEST(ListContainerTestSet, listPrintTest)
{
    //Setup the elements under test
    Op* one = new Op(1);
    Op* two = new Op(2);
    Op* three = new Op(3);
   
    ListContainer *test_container = new ListContainer();
  
    //Exercisee some func of the test element
    test_container->add_element(one);
    test_container->add_element(two);
    test_container->add_element(three);
    //test_container->print();
    //Assert that the container has at least a single element
    //otherwise we are likely to cause a segfault when accessing
    ASSERT_EQ(test_container->size(), 3);
    //test_container->swap(0,2);
    EXPECT_EQ(test_container->at(0)->evaluate(), 1);
    EXPECT_EQ(test_container->at(1)->evaluate(), 2);
    EXPECT_EQ(test_container->at(2)->evaluate(), 3);
}

TEST(ListContainerTestSet, swapTest)
{
    //Setup the elements under test
    Op* one = new Op(1);
    Op* two = new Op(2);
    Op* three = new Op(3);

    ListContainer* test_container = new ListContainer();

    //Exercisee some func of the test element
    test_container->add_element(one);
    test_container->add_element(two);
    test_container->add_element(three);
    test_container->print();
    test_container->swap(0,1);
    test_container->print();
    //Assert that the container has at least a single element
    //otherwise we are likely to cause a segfault when accessing
    EXPECT_EQ((int)test_container->at(0)->evaluate(), 2);
    EXPECT_EQ((int)test_container->at(1)->evaluate(), 1);
    EXPECT_EQ((int)test_container->at(2)->evaluate(), 3);
}

#endif //__LIST_CONTAINER_TEST__

