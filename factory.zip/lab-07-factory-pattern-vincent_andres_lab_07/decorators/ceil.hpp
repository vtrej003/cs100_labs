#ifndef __CEIL_HPP__
#define __CEIL_HPP__

#include "decorator.hpp"

class Ceil : public Decorator{

    public:
	Ceil(Base* val) : Decorator(val){};
	virtual double evaluate(){return (double)(((int)(op->evaluate()))+1);
};
	virtual std::string stringify(){return (std::to_string(op->evaluate()));};
        
};


#endif //__CEIL_HPP__
