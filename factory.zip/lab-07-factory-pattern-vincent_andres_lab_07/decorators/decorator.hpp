#ifndef __DECORATOR_HPP__
#define __DECORATOR_HPP__
#include "../ops/base.hpp"

class Decorator : public Base{
    
    public:
	Decorator();
        Decorator(Base* val){op = val;};
	virtual double evaluate() = 0;
	virtual std::string stringify() = 0;
    protected:
        Base* op;
};



#endif //__DECORATOR_HPP__
