#ifndef __PAREN_HPP__
#define __PAREN_HPP__
#include "decorator.hpp"
class Paren : public Decorator{
    public:
        Paren(Base* val) : Decorator (val){};//op = val;}
        virtual double evaluate(){};
        virtual std::string stringify(){return ("("+op->stringify()+")");}
};


#endif //__PAREN_HPP__

