#include "gtest/gtest.h"
#include "../decorators/decorator.hpp"
#include "../decorators/ceil.hpp"
#include "../decorators/abs.hpp"
#include "../ops/op.hpp"

TEST(comboTest, AbsCeilEval)) 
{
    Base* op = new Op(-3.5);
    Base* abs = new Abs(op);
    Base* test = new Ceil(abs);
    
    std::cout << test->stringify() << std::endl;
   
    EXPECT_EQ(test->evaluate(), 4);
}
