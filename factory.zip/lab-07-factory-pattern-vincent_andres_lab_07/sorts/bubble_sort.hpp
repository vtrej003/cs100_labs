#ifndef __VECTORCONTAINER_HPP___
#define __VECTORCONTAINER_HPP__
#include "container.hpp"
#include <vector>
#include <iostream>
class VectorContainer : public Container{
    protected:
        std::vector<Base*> vectorOfOps;
    public:
        VectorContainer(std::vector<Base*> vecOfOps){
                vectorOfOps = vecOfOps;
        };
        VectorContainer(){};
        ~VectorContainer(){};

        virtual void add_element(Base* element){
                vectorOfOps.push_back(element);
}

        virtual void print(){
                std::string str = "";
                for (int i = 0; i < vectorOfOps.size(); i++){
                        str += vectorOfOps.at(i)->stringify();
                }
                std::cout<<str;
        }


        virtual void sort(){
                Container* container = new VectorContainer(vectorOfOps);
                        if (sort_function){
                        std::cout<<"*Container before sort* \n";
                        std::cout<<"Vector at 0: " << vectorOfOps.at(0)->evaluate() << std::endl;
                        std::cout<<"Vector at 1: " << vectorOfOps.at(1)->evaluate() << std::endl;
                        std::cout<<"Vector at 2: " << vectorOfOps.at(2)->evaluate() << std::endl;


                        std::cout<<"Sort function is set, sorting...\n";
                        sort_function->sort(container);
                        for (int i = 0; i<container->size();i++){
                                vectorOfOps.at(i) = container->at(i);
                        }
                        std::cout<<"*Container after sort*\n";
                        std::cout<<"Vector at 0: " << vectorOfOps.at(0)->evaluate() << std::endl;
                        std::cout<<"Vector at 1: " << vectorOfOps.at(1)->evaluate() << std::endl;
                        std::cout<<"Vector at 2: " << vectorOfOps.at(2)->evaluate() << std::endl;

                }
                        else{
                        std::cout<<"Sort function is null, not good to sort./n";
                }
        }
        /*Functions Needed to Sort*/
        virtual void swap(int i, int j){
                //switch tree locations
        std::cout<<"Inside swap function\n";
        std::cout<<"We are swapping the "<<i<<" and "<< j <<" elements\n";
        std::cout<<vectorOfOps.at(i)->evaluate()<<" and "<< vectorOfOps.at(j)->evaluate()<<std::endl;
        Base* it = vectorOfOps.at(i);
        Base* jit = vectorOfOps.at(j);
        vectorOfOps.at(i) = jit;
        vectorOfOps.at(j) = it;

        }
        virtual Base* at(int i){
                //return top prt of tree at index i
                return vectorOfOps.at(i);
        }
        //return container size
        virtual int size(){
                return vectorOfOps.size();
        }
        void set_sort_function(Sort* sortFunc){
                sort_function = sortFunc;
        }
};

#endif //__VECTORCONTAINER_HPP__

