#ifndef __LIST__CONTAINER__
#define __LIST__CONTAINER__
#include <iostream>
#include <list>
#include "container.hpp"
#include "sort.hpp"
#include "selection_sort.hpp"
#include "ops/base.hpp"


class ListContainer : public Container
{
    protected:
	std::list<Base*> listOfBase;
	
    public:
        /* Constructors */
        ListContainer() : Container(){};
	ListContainer(Sort* func) : Container(func){};	 
	~ListContainer();
        /* Pure Virtual Functions */
        // push the top pointer of the tree into container
        virtual void add_element(Base* element)
	{
		listOfBase.push_back(element);
	}
                  
        // iterate through trees and output the expressions (use stringify())
        virtual void print()
	{
		if(!(listOfBase.empty()))
		{			for(int i = 0; i < listOfBase.size(); i++)
			{	
				std::cout << at(i)->stringify() << std::endl;
			}
		}	
		else
			std::cout << "ok im empty:(/n";
	}

        //calls on the previously set sorting-algorithm. Checks if sort_function is not
        // null, throw exception if otherwise
        virtual void sort()
	{
		try
		{
			sort_function->sort(this);
		}
		catch(...)
		{
			std::cout << "No sort function set" << std::endl;
		}
		
	}

	/* Functions Needed to Sort */
        
	//switch tree locations
        virtual void swap(int i, int j)
	{
		std::list<Base*>::iterator it = listOfBase.begin();
		std::advance(it, i);
		Base* tempI = at(i);
		//Base* tempJ = at(j);
		*it = at(j);
		std::advance(it, j-i);
		*it = tempI;
		
		//*it = tempJ;
		//it = at(j);
		
	}
        // get top ptr of tree at index i
        virtual Base* at(int i) 
	{
		std::list<Base*>::iterator it = listOfBase.begin();
		std::advance(it ,i);
		
		return *it;
	}
        // return container size
        virtual int size()
	{
		return listOfBase.size();
	}  
};
#endif
