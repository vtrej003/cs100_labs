#include<iostream>
#include"factory/factory.hpp"
#include"ops/base.hpp"

int main(int argc, char **argv){
	//std::string input(argv);
//	for(int i = 0; i<argc; i++){
//		std::cout<<argv[i]<<std::endl;;
//}

	Factory f;
	Base* b = f.parser(argc, argv);
	if (b == nullptr){return 1;}
	std::cout<<"Returned from parser\n";
	std::cout<<"\nThis is the string: "<<b->stringify() <<"\nThis is the evaluation: "
	<< b->evaluate()<<std::endl;
	return 0;
}
