#include "../ops/op.hpp"
#include "../ops/mult.hpp"
#include "../ops/div.hpp"
#include "../ops/add.hpp"
#include "../ops/sub.hpp"
#include "../ops/base.hpp"
#include <iostream>
#include <string>
#include <ctype.h>
class Factory{
public:
    Factory(){};
    Base* parser(int length, char** input){ 
	//std::cout<<"Parsing!\n";
	bool operationFound = false;
	std::string operation = "NULL_OPERATION";
	Base* leftOp;
	Base* rightOp;
	int it = 0 ;
	int start = 0;
 	if(input[0][0] == '.'){
		start = 1;
//		std::cout<<"Length modified from " << length;
		length = length-1;
//		std::cout<<" to " <<length<<std::endl;
	}
	for (int i = start; i <=length; i++ ){
		if((isdigit(input[i][0])|| input[i][0] == ' ' || input[i][0] == '+' || input[i][0] == '-' || input[i][0] == '*' || input[i][0] == '/')){
		//	std::cout<<"\n\nInput is VALID\n\n";
		}
		
		else{
			std::cout<<"\n\nInput '" <<input[i][0] <<"' is INVALID, returning nullptr\n";
			return nullptr;
		}
	} 
//	std::cout<<"starting at element "<<start<<std::endl;
//	std::cout<<"Input being parsed is...\n";
//	for (int i = start; i<length; i++){
//		std::cout<<input[i]<<std::endl;
//	};
//	std::cout<<"\nWith length of: "<<length<<std::endl;
	for (int i = 0; i<=length; i++){
//		std::cout<<"Spitting out input "<<input[i][0]<<std::endl;
		if (input[i][0] == '+' || input[i][0] == '-' || input[i][0] == '*' || input[i][0] == '/'){   
			operation = input[i];
                        operationFound = true;
			rightOp = new Op(std::atof(input[i+1]));
		}
	}
	if(operationFound == true){
		length--;
//		std::cout<<"This is the Operation being used: "<<operation<<std::endl;
        	int nLength = length - start - 1;
  //      	std::cout<<"This is the nLenght: "<< nLength<<std::endl;
        	char* nInput[nLength];
        	for (int jit = 0; jit<nLength; jit++){
//        	        std::cout<<"nInput initialization: "<<jit<<std::endl;
        	}
//		std::cout<<"Length before nInput: " << length<<std::endl;
        	for (int j = start; j<length; j++){
        	        if (input[j][0] == '.'){
//				std::cout<<input[j]<<" is invalid\n";
//				std::cout<<"Breaking...\n";
			}
			else{
//				std::cout<<"Loading nInput with '" << input[j]<<"'\n";
        	        	nInput[it]= input[j];
        	        	it++;
			}
        	}
//        	std::cout<<"Subparsing...\n";
        	leftOp = parser(nLength, nInput);
//		std::cout<<"We've returned from the subparsing\n";
	}
	else{
		leftOp = new Op(std::atof(input[start]));
		return leftOp;
        }
//		std::cout<<"Instantializing leftOp with input at pos "<<start<<std::endl;
	///	leftOp = new Op(std::atof(input[start]));
//		std::cout<<"leftOp instantialized\n";
	///	return leftOp;
	//	}
	//	else {return nullptr;}
	//}
	if (operation == "*"){
		return new Mult(leftOp, rightOp);
	} 
	else if (operation == "/"){
		return new Div(leftOp, rightOp);	
	}
	else if (operation == "-"){
		return new Sub(leftOp, rightOp);
	} 
	else if(operation == "+"){
//		std::cout<<"Instantiating an addition op\n";
    		return new Add(leftOp, rightOp);
	}
	return NULL;
        
    }
};
