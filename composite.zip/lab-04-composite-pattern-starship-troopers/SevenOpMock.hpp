#ifndef __SEVENOPMOCK_HPP__
#define __SEVENOPMOCK_HPP__
class SevenOpMock: public Base {
    public:
        SevenOpMock() { };

        virtual double evaluate() { return 7.0; }
        virtual std::string stringify() { return "7.0"; }
};

#endif //__SEVENOPMOCK_HPP__
