#pragma once
#include "base.hpp"
class NegThreeOpMock: public Base {
    public:
        NegThreeOpMock() { };

        virtual double evaluate() { return -3.0; }
        virtual std::string stringify() { return "3.0";}
};
