#ifndef __SIXOPMOCK_HPP__
#define __SIXOPMOCK_HPP__
class SixOpMock: public Base {
    public:
        SixOpMock() { };

        virtual double evaluate() { return 6.0; }
        virtual std::string stringify() { return "6.0"; }
};

#endif //__SIXOPMOCK_HPP__

