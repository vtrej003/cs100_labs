#pragma once
#include "base.hpp"
class MockOpPosFour : public Base 
{
    public:
        MockOpPosFour() {};

	virtual double evaluate() { return 4.0; }
	virtual std::string stringify() { return "4.0"; }
	
};
