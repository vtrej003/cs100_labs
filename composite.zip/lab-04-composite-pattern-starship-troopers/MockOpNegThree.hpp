#pragma once
#include "base.hpp"

class MockOpNegThree : public Base 
{
    public:
        MockOpNegThree() {};

	virtual double evaluate() { return -3.0; }
	virtual std::string stringify() { return "-3.0" ;}
	
};
