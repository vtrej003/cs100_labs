#pragma once
#ifndef __ADD_HPP__
#define __ADD_HPP__

#include "base.hpp"

class Add : public Base {
    public:
        Add( Base* a, Base* b)
	{
	    this->op1 = a;
	    this->op2 = b;  	
	};
        virtual double evaluate() 
	{
	    return op1->evaluate() + op2->evaluate();
	}
        virtual std::string stringify()
	{
	    return op1->stringify() + " + " + op2->stringify();
	}
    protected:
    Base* op1 = NULL;
    Base* op2 = NULL; 
};

#endif //__ADD_HPP__
