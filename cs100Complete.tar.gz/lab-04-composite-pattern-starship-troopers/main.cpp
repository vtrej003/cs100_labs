#include <iostream>
#include "base.hpp"
#include "op.hpp"
#include "pow.hpp"
#include "add.hpp"
#include "sub.hpp"
#include "mult.hpp"
#include "div.hpp"
#include "rand.hpp"

int main() {
    
    Base* negThree = new Op(-3);
    Base* seven = new Op(7);
    Base* four = new Op(4);
    Base* two = new Op(2);
    Base* pow = new Pow(seven, four);
    Base* mult = new Mult(seven, four);
    Rand* rand = new Rand();
    Base* add = new Add(negThree, mult);
    Base* minus = new Sub(add, two);
    Base* mult2 = new Mult(negThree, seven);
    Base* div = new Div(mult, negThree);
    Base* mult1 = new Mult(div, rand);
    std::cout << mult->stringify() << " = " << mult->evaluate() << std::endl;
    std::cout << div->stringify() << " = " << div->evaluate() << std::endl;
    std::cout << rand->stringify() << " = " << rand->evaluate() << std::endl;
    std::cout << pow->stringify() << " = " << pow->evaluate() << std::endl;

    return 0;
}

