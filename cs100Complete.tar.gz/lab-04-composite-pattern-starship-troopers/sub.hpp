#ifndef __SUB_HPP__
#define __SUB_HPP__

#include "base.hpp"

class Sub : public Base {
    public:
        Sub( Base* a, Base* b)
	{
	    this->op1 = a;
	    this->op2 = b;  	
	};
        virtual double evaluate() 
	{
	    return op1->evaluate() - op2->evaluate();
	}
        virtual std::string stringify()
	{
	    return op1->stringify() + " - " + op2->stringify();
	}
    protected:
    Base* op1 = NULL;
    Base* op2 = NULL; 
};

#endif //__SUB_HPP__
