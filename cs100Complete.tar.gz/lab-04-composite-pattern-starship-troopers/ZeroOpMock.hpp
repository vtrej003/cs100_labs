#ifndef __ZEROOPMOCK_HPP__
#define __ZEROOPMOCK_HPP__
class ZeroOpMock: public Base {
    public:
        ZeroOpMock() { };
        virtual double evaluate() { return 0; }
        virtual std::string stringify() { return "0"; }
};
#endif //__ZEROOPMOCK_HPP__
