#ifndef __SUB_TEST_HPP__
#define __SUB_TEST_HPP__

#include "gtest/gtest.h"
#include "sub.hpp"
#include "MockOpNegThree.hpp"
#include "MockOpZero.hpp"
#include "MockOpPosFour.hpp"

TEST(SubTest, Sub_OpOp_Eval) {
    MockOpNegThree* mockNegThree = new MockOpNegThree();
    MockOpPosFour* mockPosFour = new MockOpPosFour();
    Sub* test = new Sub(mockNegThree, mockPosFour);
    std::cout << test->stringify() + "\n";
    EXPECT_EQ(test->evaluate(), -7);
}
TEST(SubTest, Sub_Nested_Eval) {
    MockOpNegThree* mockNegThree = new MockOpNegThree();
    MockOpPosFour* mockPosFour = new MockOpPosFour();
    Sub* mockSub = new Sub(mockNegThree,mockPosFour);
    std::cout << "mockSub Created\n";
    Sub* test = new Sub(mockSub,mockPosFour);
    std::cout << test->stringify() + "\n";
    EXPECT_EQ(test->evaluate(), -11);
}
TEST(SubTest, Sub_OP_Zero_Eval) {
    MockOpNegThree* mockNegThree = new MockOpNegThree();
    MockOpZero* mockZero = new MockOpZero();
    Sub* test = new Sub(mockNegThree,mockZero);
    std::cout << "mockSub Created\n";
    std::cout << test->stringify() + "\n";
    EXPECT_EQ(test->evaluate(), -3);
}
#endif //__SUB_TEST_HPP__

