#pragma once
#include "base.hpp"

class MockOpZero : public Base 
{
    public:
        MockOpZero() {};

	virtual double evaluate() { return 0.0; }
	virtual std::string stringify() { return "0.0"; }
	
};
