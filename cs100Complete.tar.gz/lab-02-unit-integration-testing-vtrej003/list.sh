for file in n ./*
do
    echo $(basename "$file")
done
