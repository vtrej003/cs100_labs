#include "gtest/gtest.h"
#include "list_container_test.hpp"
#include "selection_sort_test.hpp"
#include "vector_container_test.hpp"
#include "bubble_sort_test.hpp"

int main(int argc, char **argv) {
  ::testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}
