#ifndef __BUBBLESORTTEST_HPP__
#define __BUBBLESORTTEST_HPP__

#include "gtest/gtest.h"
#include "container.hpp"
#include "vector_container.hpp"
#include "sort.hpp"
#include "bubble_sort.hpp"
#include "ops/op.hpp"
#include "ops/mult.hpp"
#include "ops/add.hpp"
#include "ops/sub.hpp"

TEST(SortBubbleTestSet, BubbleSortTest) {
    Op* seven = new Op(7);
    Op* four = new Op(4);
    Mult* TreeA = new Mult(seven, four);

    Op* three = new Op(3);
    Op* two = new Op(2);
    Add* TreeB = new Add(three, two);

    Op* ten = new Op(10);
    Op* six = new Op(6);
    Sub* TreeC = new Sub(ten, six);

    VectorContainer* container = new VectorContainer();
    std::cout << "bubble sort test created vector. its size is: " << container->size() << std::endl;

    container->add_element(TreeA);
    container->add_element(TreeB);
    container->add_element(TreeC);
    
    std::cout << "Added elements to bubble sort test container. Now printing container->print()" << std::endl;
    container->print();

    std::cout << "\nstart Assert and expect\n";
  
    ASSERT_EQ(container->size(), 3);
    EXPECT_EQ(container->at(0)->evaluate(), 28);
    EXPECT_EQ(container->at(1)->evaluate(), 5);
    EXPECT_EQ(container->at(2)->evaluate(), 4);

    std::cout << "before sort assert and expect done\n";
    std::cout << "setting sort and running sort\n" << "container size: " << container->size() << std::endl;
    
    container->set_sort_function(new BubbleSort());
    container->sort();
    std::cout << "sort complete\n" << "printing container now\n";
   
    container->print();

    std::cout << "\nPost-sort: Assert expect call now\n";

    ASSERT_EQ(container->size(), 3);
    EXPECT_EQ(container->at(0)->evaluate(), 4);
    EXPECT_EQ(container->at(1)->evaluate(), 5);
    EXPECT_EQ(container->at(2)->evaluate(), 28);

}
#endif //__BUBBLESORTTEST_HPP__

