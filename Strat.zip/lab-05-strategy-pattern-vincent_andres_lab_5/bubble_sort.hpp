#ifndef __BUBBLESORT_HPP__
#define __BUBBLESORT_HPP__

#include "sort.hpp"
#include "container.hpp"

class BubbleSort : public Sort
{
    public:
	BubbleSort() : Sort(){};

        virtual void sort(Container* container)
	{
            int i, j; 
 
	    for (i = 0; i < container->size(); i++)
	    {      
 	        for (j = 0; j < container->size() - i; j++)
	        {  
	            if (container->at(j)->evaluate() > container->at(j+1)->evaluate())
		    {
			 container->swap(j, j+1);
		    }
		}
	    }
	}
};

	









/* int i, j, flag = 1;    // set flag to 1 to start first pass
          Base* temp;             // holding variable
          int cLength = c->size(); 
          for(i = 1; (i <= cLength) && flag; i++){
              flag = 0;
              for (j = 0; j < (cLength - 1); j++)
              {
                   if (c->at(j + 1)->evaluate() > c->at(j)->evaluate()){ 
                     //   temp = c->at(j);             // swap elements
                        c->swap(c->at(j)->evaluate(), c->at(j+1)->evaluate());
			//c->at(j) = c->at(j + 1);
                       // c->at(j + 1) = temp;
                        flag = 1;               // indicates that a swap occurred.
                   }
              }
         }   //arrays are passed to functions by address; nothing is returned*/    

#endif //__BUBBLESORT_HPP__
