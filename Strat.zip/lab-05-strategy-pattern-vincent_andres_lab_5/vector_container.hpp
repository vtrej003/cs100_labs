#ifndef __VECTORCONTAINER_HPP__
#define __VECTORCONTAINER_HPP__
#include <iostream>
#include <vector>
#include "container.hpp"
#include "sort.hpp"
#include "bubble_sort.hpp"
#include "ops/base.hpp"

class VectorContainer : public Container{
    protected:
	std::vector<Base*> vectorOfOps;	
    public:
	VectorContainer() : Container(){};
	VectorContainer(Sort* func) : Container(func){};	
	~VectorContainer();

	virtual void add_element(Base* element){
		vectorOfOps.push_back(element);	
	}

	virtual void print()
	{
		if(!(vectorOfOps.empty()))
		{
			for(int i = 0; i < vectorOfOps.size(); i++)
			{
				std::cout << at(i)->stringify() << std::endl;
			}

		/*	std::cout << "Initiating print call\n";
			std::string str = "";
			for (int i = 0; i < vectorOfOps.size(); i++)
			{
			str += vectorOfOps.at(i)->stringify();	
			}
		*/
		}
		else
			std::cout << "vector is empty" << std::endl;
	}


	virtual void sort()
	{
			// HOW TF DO WE PASS IN A CONTAINER W/ ELEMENTS FOR SORT TO USE
	/*	Container* container = new VectorContainer();
			if (sort_function){
			std::cout<<"Sort function is set, sorting.../n";
			sort_function->sort( container);
		} 		
			else{
			std::cout<<"Sort function is null, not good to sort./n";
	
		}*/
		try
		{
			sort_function->sort(this);
		}
		catch(...)
		{
			std::cout << "No sort function set" << std::endl;
		}

	}
	
	/*Functions Needed to Sort*/
	virtual void swap(int i, int j){
		//switch tree locations
		Base* temp = at(i);
		//std::cout << "temp is: " <<  temp->stringify() << std::endl;
		vectorOfOps[i] = at(j);
		//std::cout << "vector at i is now: " << vectorOfOps[i]->stringify() << std::endl;
		vectorOfOps[j] = temp;
		//std::cout << "vector at j is now: " << vectorOfOps[j]->stringify() << std::endl;
		std::cout << "swap finishing: quick Print():\n";
		print();
		/*Base* posI = vectorOfOps.at(i);
		Base* posJ = vectorOfOps.at(j);
		vectorOfOps.at(i) = ;
		vectorOfOps.at(j) = it;
	*/
			
	}
	virtual Base* at(int i)
	{
		//return top prt of tree at index i 
		std::cout << "Base* at function call at i is: " << vectorOfOps[i]->stringify() << std::endl;
		return vectorOfOps[i];				
	}
	//return container size
	virtual int size(){
		return vectorOfOps.size();	
	}
	/*void set_sort_function(Sort* sortFunc){
		sort_function = sortFunc;
	}*/
};
#endif //__VECTORCONTAIN://www.google.com/search?client=firefox-b-1-e&q=vector+is+emptyER_HPP__
