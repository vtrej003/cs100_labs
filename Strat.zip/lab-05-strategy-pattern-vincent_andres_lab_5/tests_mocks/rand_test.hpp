
#ifndef __RAND_TEST_HPP__
#define __RAND_TEST_HPP__

#include "gtest/gtest.h"

#include "/home/csmajs/aestr074/lab-05-strategy-pattern-vincent_andres_lab_5/ops/rand.hpp"

TEST(RandTest, RandEvaluate) {
    Rand* test = new Rand();
    EXPECT_EQ(test->evaluate(), 1);
}

TEST(RandTest, RandEvaluate1) {
    Rand* test = new Rand();
    EXPECT_EQ(test->evaluate(), 2);
}

TEST(RandTest, RandEvaluate2) {
    Rand* test = new Rand();
    EXPECT_EQ(test->evaluate(), 3);
}


#endif //__OP_TEST_HPP__

