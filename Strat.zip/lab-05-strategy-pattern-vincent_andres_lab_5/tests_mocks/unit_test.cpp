#include "gtest/gtest.h"
#include "list_container_test.hpp"
#include "tests_mocks/div_test.hpp"
#include "tests_mocks/op_test.hpp"
#include "tests_mocks/mult_test.hpp"
#include "tests_mocks/rand_test.hpp"
#include "tests_mocks/pow_test.hpp"
#include "tests_mocks/add_test.hpp"
#include "tests_mocks/sub_test.hpp"

int main(int argc, char **argv) {
  ::testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}
