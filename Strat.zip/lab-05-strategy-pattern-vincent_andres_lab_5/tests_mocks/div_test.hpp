#ifndef __DIV_TEST_HPP__
#define __DIV_TEST_HPP__

#include "gtest/gtest.h"

#include "ops/div.hpp"
#include "SixOpMock.hpp"
#include "NegThreeOpMock.hpp"
#include "ZeroOpMock.hpp"
#include "ops/mult.hpp"
TEST(DivTest, DivEvaluateNeg) {
    SixOpMock* sixOp = new SixOpMock();
    NegThreeOpMock* negOp = new NegThreeOpMock();
    Div* test = new Div(sixOp, negOp);
    EXPECT_EQ(test->evaluate(), -2);
}
TEST(DivTest, DivEvaluateZero) {
    SixOpMock* sixOp = new SixOpMock();
    ZeroOpMock* zeroOp = new ZeroOpMock();
    Div* test = new Div(zeroOp, sixOp);
    EXPECT_EQ(test->evaluate(), 0);
}

TEST(DivTest, DivEvaluateNegAndOperator) {
    SixOpMock* sixOp = new SixOpMock();
    NegThreeOpMock* negOp = new NegThreeOpMock();
    Mult* mult = new Mult(sixOp, negOp);
    Div* test = new Div(mult, negOp);
    EXPECT_EQ(test->evaluate(), 6);
}

TEST(DivTest, DivEvaluateNegToString) {
    SixOpMock* sixOp = new SixOpMock();
    NegThreeOpMock* negOp = new NegThreeOpMock();
    Div* test = new Div(sixOp, negOp);
    EXPECT_EQ(test->stringify(),"6.0/3.0");
}

TEST(DivTest, DivEvaluateZeroToString) {
    SixOpMock* sixOp = new SixOpMock();
    ZeroOpMock* zeroOp = new ZeroOpMock();
    Div* test = new Div(zeroOp, sixOp);
    EXPECT_EQ(test->evaluate(), 0);
}


#endif //__DIV_TEST_HPP__

