#ifndef __SUB_TEST_HPP__
#define __SUB_TEST_HPP__

#include "gtest/gtest.h"
#include "/home/csmajs/aestr074/lab-05-strategy-pattern-vincent_andres_lab_5/ops/sub.hpp"
#include "NegThreeOpMock.hpp"
#include "ZeroOpMock.hpp"
#include "MockOpPosFour.hpp"

TEST(SubTest, Sub_OpOp_Eval) {
    NegThreeOpMock* mockNegThree = new NegThreeOpMock();
    MockOpPosFour* mockPosFour = new MockOpPosFour();
    Sub* test = new Sub(mockNegThree, mockPosFour);
    std::cout << test->stringify() + "\n";
    EXPECT_EQ(test->evaluate(), -7);
}
TEST(SubTest, Sub_Nested_Eval) {
    NegThreeOpMock* mockNegThree = new NegThreeOpMock();
    MockOpPosFour* mockPosFour = new MockOpPosFour();
    Sub* mockSub = new Sub(mockNegThree,mockPosFour);
    std::cout << "mockSub Created\n";
    Sub* test = new Sub(mockSub,mockPosFour);
    std::cout << test->stringify() + "\n";
    EXPECT_EQ(test->evaluate(), -11);
}
TEST(SubTest, Sub_OP_Zero_Eval) {
    NegThreeOpMock* mockNegThree = new NegThreeOpMock();
    ZeroOpMock* mockZero = new ZeroOpMock();
    Sub* test = new Sub(mockNegThree,mockZero);
    std::cout << "mockSub Created\n";
    std::cout << test->stringify() + "\n";
    EXPECT_EQ(test->evaluate(), -3);
}
#endif //__SUB_TEST_HPP__

