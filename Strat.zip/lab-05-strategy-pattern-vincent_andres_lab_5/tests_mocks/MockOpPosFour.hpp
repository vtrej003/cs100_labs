#pragma once
#include "/home/csmajs/aestr074/lab-05-strategy-pattern-vincent_andres_lab_5/base.hpp"
class MockOpPosFour : public Base 
{
    public:
        MockOpPosFour() {};

	virtual double evaluate() { return 4.0; }
	virtual std::string stringify() { return "4.0"; }
	
};
