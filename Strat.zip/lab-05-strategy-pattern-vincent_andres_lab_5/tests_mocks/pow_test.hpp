#ifndef __POW_TEST_HPP__
#define __POW_TEST_HPP__

#include "gtest/gtest.h"
#include "NegThreeOpMock.hpp"
#include "ZeroOpMock.hpp"
#include "MockOpPosFour.hpp"
#include "/home/csmajs/aestr074/lab-05-strategy-pattern-vincent_andres_lab_5/ops/pow.hpp"

TEST(PowTest, Pow_OpOp_Eval) {
    NegThreeOpMock* mockNegThree = new NegThreeOpMock();
    MockOpPosFour* mockPosFour = new MockOpPosFour();
    Pow* test = new Pow(mockNegThree, mockPosFour);
    std::cout << test->stringify() + "\n";
    EXPECT_EQ(test->evaluate(), 81);
}
TEST(PowTest, Pow_Nested_Eval) {
    NegThreeOpMock* mockNegThree = new NegThreeOpMock();
    MockOpPosFour* mockPosFour = new MockOpPosFour();
    Pow* mockPow = new Pow(mockNegThree,mockPosFour);
    std::cout << "mockPow Created\n";
    Pow* test = new Pow(mockPow,mockPosFour);
    std::cout << test->stringify() + "\n";
    EXPECT_EQ(test->evaluate(), 43046721.0);
}
TEST(PowTest, Pow_OP_Zero_Eval) {
    NegThreeOpMock* mockNegThree = new NegThreeOpMock();
    ZeroOpMock* mockZero = new ZeroOpMock();
    Pow* test = new Pow(mockNegThree,mockZero);
    std::cout << "mockPow Created\n";
    std::cout << test->stringify() + "\n";
    EXPECT_EQ(test->evaluate(), 1);
}
#endif //__POW_TEST_HPP__

