#pragma once
#include "/home/csmajs/aestr074/lab-05-strategy-pattern-vincent_andres_lab_5/base.hpp"
class NegThreeOpMock: public Base {
    public:
        NegThreeOpMock() { };

        virtual double evaluate() { return -3.0; }
        virtual std::string stringify() { return "3.0";}
};
