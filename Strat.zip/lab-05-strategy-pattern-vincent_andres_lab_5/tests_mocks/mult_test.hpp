#ifndef __MULT_TEST_HPP__
#define __MULT_TEST_HPP__

#include "gtest/gtest.h"

#include "/home/csmajs/aestr074/lab-05-strategy-pattern-vincent_andres_lab_5/ops/mult.hpp"
#include "SevenOpMock.hpp"
#include "ZeroOpMock.hpp"
#include "SixOpMock.hpp"
#include "NegThreeOpMock.hpp"
#include "/home/csmajs/aestr074/lab-05-strategy-pattern-vincent_andres_lab_5/ops/div.hpp"
TEST(MultTest, MultEvaluateNeg) {
    SixOpMock* sixOp = new SixOpMock();
    NegThreeOpMock* negOp = new NegThreeOpMock();
    Mult* test = new Mult(sixOp, negOp);
    EXPECT_EQ(test->evaluate(), -18);
}
TEST(MultTest, MultEvaluateZero) {
    SixOpMock* sixOp = new SixOpMock();
    ZeroOpMock* zeroOp = new ZeroOpMock();
    Mult* test = new Mult(zeroOp, sixOp);
    EXPECT_EQ(test->evaluate(), 0);
}

TEST(MultTest, MultEvaluateNegAndOperator) {
    SixOpMock* sixOp = new SixOpMock();
    NegThreeOpMock* negOp = new NegThreeOpMock();
    Div* div = new Div(sixOp, negOp);
    Mult* test = new Mult(div, negOp);
    EXPECT_EQ(test->evaluate(), 6);
}

TEST(MultTest, MultEvaluateNegToString) {
    SixOpMock* sixOp = new SixOpMock();
    NegThreeOpMock* negOp = new NegThreeOpMock();
    Mult* test = new Mult(sixOp, negOp);
    EXPECT_EQ(test->stringify(),"6.0*3.0");
}

TEST(MultTest, MultEvaluateZeroToString) {
    SixOpMock* sixOp = new SixOpMock();
    ZeroOpMock* zeroOp = new ZeroOpMock();
    Mult* test = new Mult(zeroOp, sixOp);
    EXPECT_EQ(test->evaluate(), 0);
}



#endif //__OP_TEST_HPP__

