#ifndef __TESTVECTORCONTAINER_HPP__
#define __TESTVECTORCONTAINER_HPP__
#include "gtest/gtest.h" 
#include "ops/mult.hpp"
#include "ops/op.hpp"
#include "ops/div.hpp"
#include "container.hpp"
#include "vector_container.hpp"
TEST(VectorTest, PushTest) {
    Op* seven = new Op(7);
    VectorContainer* testVector = new VectorContainer();
    testVector->add_element(seven);
    ASSERT_EQ(testVector->size(), 1);		     
    EXPECT_EQ(testVector->at(0)->evaluate(), 7);
}

TEST(VectorTest, SwapTest) {
    Op* seven = new Op(7);
    Op* six = new Op(6);
    Op* five = new Op(5);
    VectorContainer* testVector = new VectorContainer();
    testVector->add_element(seven);
    testVector->add_element(six);
    testVector->add_element(five);
    ASSERT_EQ(testVector->size(), 3);
    EXPECT_EQ(testVector->at(1)->evaluate(), 6);
    EXPECT_EQ(testVector->at(2)->evaluate(), 5);
    testVector->swap(1, 2);
    EXPECT_EQ(testVector->at(1)->evaluate(), 5);
    EXPECT_EQ(testVector->at(2)->evaluate(), 6);
}





#endif //__TESTVECTORCONTAINER_HPP
