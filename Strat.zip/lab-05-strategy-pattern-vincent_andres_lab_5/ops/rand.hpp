#ifndef __RAND_HPP__
#define __RAND_HPP__
#include "base.hpp"

class Rand : public Base {
    	private:
	double randNum;
	public:
        Rand() : Base() {randNum = rand()%100;}
        virtual double evaluate() {
		return randNum;
	}
        virtual std::string stringify(){	
		return std::to_string(randNum) ;
	}
};



#endif //__RAND_HPP__

