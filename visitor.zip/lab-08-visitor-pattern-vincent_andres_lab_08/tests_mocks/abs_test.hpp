#include "gtest/gtest.h"
#include "../decorators/decorator.hpp"
#include "../decorators/abs.hpp"
#include "../decorators/ceil.hpp"
#include "../ops/op.hpp"

//checked the double decor combination
TEST(AbsTest, positiveNumCheck) 
{
    Base* temp = new Op(-3);
    Base* test = new Abs(temp);
    Base* ceil = new Ceil(test);
    
    std::cout << ceil->stringify() << std::endl;
   
    EXPECT_EQ(ceil->evaluate(), 4);
}
