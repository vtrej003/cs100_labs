#include "gtest/gtest.h"
#include "../decorators/decorator.hpp"
#include "../decorators/floor.hpp"
#include "../ops/op.hpp"

TEST(FloorTest, RoundingDown) 
{
    Base* temp = new Op(3.5);
    Base* test = new Floor(temp);
    
    std::cout << test->stringify() << std::endl;
    EXPECT_EQ(test->evaluate(), 3);
}
