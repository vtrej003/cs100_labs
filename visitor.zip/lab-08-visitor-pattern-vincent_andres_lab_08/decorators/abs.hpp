#ifndef __ABS_HPP__
#define __ABS_HPP__

#include <cmath>
#include "decorator.hpp"

class Abs : public Decorator{

    public:
	Abs(Base* val) : Decorator(val){};
	virtual double evaluate()
	{
	     
            return std::abs(op->evaluate());

	};
	virtual std::string stringify(){return (std::to_string(op->evaluate()));};
        virtual Iterator * create_iterator()
        {
             return new UnaryIterator(this);
        }
        virtual Base* get_left()
        {
            return op1;
        }
        virtual Base* get_right()
        {
            return nullptr;
        }

        virtual void accept(CountVisitor* v)
        {
            v->visit_abs();
        }
     protected:
        Base* op1;

};


#endif //__ABS_HPP__
