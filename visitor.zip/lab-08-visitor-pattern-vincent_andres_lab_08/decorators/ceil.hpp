#ifndef __CEIL_HPP__
#define __CEIL_HPP__

#include "decorator.hpp"

class Ceil : public Decorator{

    public:
	Ceil(Base* val) : Decorator(val){op1 = val;};
	virtual double evaluate()
        {
            return (double)(((int)(op->evaluate()))+1);
        };
	virtual std::string stringify(){return (std::to_string(op->evaluate()));};
        
         virtual Iterator * create_iterator()
        {
             return new UnaryIterator(this);
        }
        virtual Base* get_left()
        {
            return op1;
        }
        virtual Base* get_right()
        {
            return nullptr;
        }

        virtual void accept(CountVisitor* v)
        {
            v->visit_ceil();
        }

    protected:
        Base* op1 = nullptr;

};


#endif //__CEIL_HPP__
