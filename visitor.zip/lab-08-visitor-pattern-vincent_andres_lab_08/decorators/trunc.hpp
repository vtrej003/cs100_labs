#ifndef __TRUNCATE_HPP__
#define __TRUNCATE_HPP__
#include "decorator.hpp"
class Truncate : public Decorator{
    public:
	Truncate(Base* val) : Decorator(val){};
	virtual double evaluate(){};
	virtual std::string stringify(){return (std::to_string(op->evaluate()));}
       
         virtual Iterator * create_iterator()
        {
             return new UnaryIterator(this);
        }
        virtual Base* get_left()
        {
            return op1;
        }
        virtual Base* get_right()
        {
            return nullptr;
        }

        virtual void accept(CountVisitor* v)
        {
            v->visit_trunc();
        }

    protected:
        Base* op1 = nullptr;

};


#endif //__TRUNCATE_HPP__
