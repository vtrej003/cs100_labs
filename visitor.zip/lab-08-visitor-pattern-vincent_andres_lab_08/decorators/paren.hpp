#ifndef __PAREN_HPP__
#define __PAREN_HPP__
#include "decorator.hpp"
class Paren : public Decorator{
    public:
        Paren(Base* val) : Decorator (val)
        {
            this->op1 = val;
        }
        virtual double evaluate(){};
        virtual std::string stringify(){return ("(" + op1->stringify() + ")");}
        
        virtual Iterator * create_iterator()
        {
             return new UnaryIterator(this);
        }
        virtual Base* get_left()
        {
            return op1;
        }
        virtual Base* get_right()
        {
            return nullptr;
        } 
        virtual void accept(CountVisitor* v)
        {
            v->visit_paren();
        }
    protected:
        Base* op1 = nullptr;
};


#endif //__PAREN_HPP__

