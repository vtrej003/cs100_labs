#include<iostream>
#include"ops/base.hpp"
#include"ops/op.hpp"
#include"ops/add.hpp"
#include"ops/div.hpp"
#include"ops/mult.hpp"
#include"ops/pow.hpp"
#include"ops/rand.hpp"
#include"ops/sub.hpp"

#include"visitor.hpp"
#include"iterator.hpp"

#include"containers/container.hpp"
#include"sorts/sort.hpp"
#include"decorators/decorator.hpp"
#include"decorators/paren.hpp"
#include"decorators/ceil.hpp"
#include"decorators/trunc.hpp"
#include"decorators/floor.hpp"
int main()
{
       std::cout << "help"; 
        CountVisitor * visitor = new CountVisitor();
        Base* op1 = new Op(1);
	Base* op2 = new Op(2);
	Base* op3 = new Op(3);
        Base* op4 = new Op(4);
	Base* add = new Add(op1, op2);
        Base* mult = new Mult(op3,op4);
	Base* sub = new Sub(mult, add);
        Base* dummy = new Paren(sub);
	
	std::cout << "dummy stringify: " << dummy->stringify();

	std::cout << "--- PreOrder Iteration ---" << std::endl;
               
	PreorderIterator* pre_itr = new PreorderIterator(dummy);
	for(pre_itr->first(); !pre_itr->is_done(); pre_itr->next()) {
		std::cout << pre_itr->current()->stringify();
                pre_itr->current()->accept(visitor);
		std::cout << std::endl;
	}
        std::cout << "this is addcount: " << visitor->add_count() << std::endl;
        //std::cout << sub->evaluate(); 
   return 0 ;
}

